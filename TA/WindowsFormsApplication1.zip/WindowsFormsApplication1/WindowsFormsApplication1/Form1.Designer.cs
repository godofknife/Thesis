﻿namespace WindowsFormsApplication1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.DictionaryFileDialog = new System.Windows.Forms.OpenFileDialog();
            this.openFileDialog2 = new System.Windows.Forms.OpenFileDialog();
            this.DictionaryButton = new System.Windows.Forms.Button();
            this.DictionaryTextBox = new System.Windows.Forms.TextBox();
            this.DictionaryLabel = new System.Windows.Forms.Label();
            this.listView1 = new System.Windows.Forms.ListView();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.checkButton = new System.Windows.Forms.Button();
            this.SuggestingButton = new System.Windows.Forms.Button();
            this.suggestionbox = new System.Windows.Forms.ListBox();
            this.label2 = new System.Windows.Forms.Label();
            this.addWordTextbox = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // DictionaryFileDialog
            // 
            this.DictionaryFileDialog.FileName = "openFileDialog1";
            // 
            // openFileDialog2
            // 
            this.openFileDialog2.FileName = "openFileDialog2";
            // 
            // DictionaryButton
            // 
            this.DictionaryButton.Location = new System.Drawing.Point(203, 25);
            this.DictionaryButton.Name = "DictionaryButton";
            this.DictionaryButton.Size = new System.Drawing.Size(75, 23);
            this.DictionaryButton.TabIndex = 0;
            this.DictionaryButton.Text = "Browse";
            this.DictionaryButton.UseVisualStyleBackColor = true;
            this.DictionaryButton.Click += new System.EventHandler(this.button1_Click);
            // 
            // DictionaryTextBox
            // 
            this.DictionaryTextBox.Location = new System.Drawing.Point(18, 27);
            this.DictionaryTextBox.Name = "DictionaryTextBox";
            this.DictionaryTextBox.Size = new System.Drawing.Size(182, 20);
            this.DictionaryTextBox.TabIndex = 1;
            // 
            // DictionaryLabel
            // 
            this.DictionaryLabel.AutoSize = true;
            this.DictionaryLabel.Location = new System.Drawing.Point(13, 13);
            this.DictionaryLabel.Name = "DictionaryLabel";
            this.DictionaryLabel.Size = new System.Drawing.Size(148, 13);
            this.DictionaryLabel.TabIndex = 2;
            this.DictionaryLabel.Text = "Browse for the dictionary file...";
            // 
            // listView1
            // 
            this.listView1.GridLines = true;
            this.listView1.Location = new System.Drawing.Point(16, 54);
            this.listView1.Name = "listView1";
            this.listView1.Size = new System.Drawing.Size(259, 472);
            this.listView1.TabIndex = 2;
            this.listView1.UseCompatibleStateImageBehavior = false;
            this.listView1.View = System.Windows.Forms.View.List;
            // 
            // richTextBox1
            // 
            this.richTextBox1.Location = new System.Drawing.Point(319, 54);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(389, 253);
            this.richTextBox1.TabIndex = 3;
            this.richTextBox1.Text = "";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(320, 10);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(145, 13);
            this.label1.TabIndex = 6;
            this.label1.Text = "Browse for the file to check...";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(319, 24);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(182, 20);
            this.textBox1.TabIndex = 5;
            // 
            // checkButton
            // 
            this.checkButton.Enabled = false;
            this.checkButton.Location = new System.Drawing.Point(507, 23);
            this.checkButton.Name = "checkButton";
            this.checkButton.Size = new System.Drawing.Size(75, 23);
            this.checkButton.TabIndex = 4;
            this.checkButton.Text = "Browse";
            this.checkButton.UseVisualStyleBackColor = true;
            this.checkButton.Click += new System.EventHandler(this.checkButton_Click);
            // 
            // SuggestingButton
            // 
            this.SuggestingButton.Enabled = false;
            this.SuggestingButton.Location = new System.Drawing.Point(319, 313);
            this.SuggestingButton.Name = "SuggestingButton";
            this.SuggestingButton.Size = new System.Drawing.Size(104, 23);
            this.SuggestingButton.TabIndex = 7;
            this.SuggestingButton.Text = "Begin Suggesting";
            this.SuggestingButton.UseVisualStyleBackColor = true;
            this.SuggestingButton.Click += new System.EventHandler(this.SuggetionButton_Click);
            // 
            // suggestionbox
            // 
            this.suggestionbox.FormattingEnabled = true;
            this.suggestionbox.Location = new System.Drawing.Point(319, 356);
            this.suggestionbox.Name = "suggestionbox";
            this.suggestionbox.Size = new System.Drawing.Size(389, 225);
            this.suggestionbox.TabIndex = 8;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(316, 339);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(357, 13);
            this.label2.TabIndex = 9;
            this.label2.Text = "Click on the words in question below to see where they are within the file...";
            this.label2.Visible = false;
            // 
            // addWordTextbox
            // 
            this.addWordTextbox.Location = new System.Drawing.Point(18, 533);
            this.addWordTextbox.Name = "addWordTextbox";
            this.addWordTextbox.Size = new System.Drawing.Size(197, 20);
            this.addWordTextbox.TabIndex = 10;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(221, 530);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(54, 23);
            this.button1.TabIndex = 11;
            this.button1.Text = "Add";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(721, 591);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.addWordTextbox);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.suggestionbox);
            this.Controls.Add(this.SuggestingButton);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.checkButton);
            this.Controls.Add(this.richTextBox1);
            this.Controls.Add(this.listView1);
            this.Controls.Add(this.DictionaryLabel);
            this.Controls.Add(this.DictionaryTextBox);
            this.Controls.Add(this.DictionaryButton);
            this.Name = "Form1";
            this.Text = "Spell Checker";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.OpenFileDialog DictionaryFileDialog;
        private System.Windows.Forms.OpenFileDialog openFileDialog2;
        private System.Windows.Forms.Button DictionaryButton;
        private System.Windows.Forms.TextBox DictionaryTextBox;
        private System.Windows.Forms.Label DictionaryLabel;
        private System.Windows.Forms.ListView listView1;
        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button checkButton;
        private System.Windows.Forms.Button SuggestingButton;
        private System.Windows.Forms.ListBox suggestionbox;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox addWordTextbox;
        private System.Windows.Forms.Button button1;
    }
}

